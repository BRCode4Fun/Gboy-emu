# Gboy-emu
An emulator for the Gameboy console, written in Rust
![image](https://drive.google.com/uc?export=view&id=17l_p7HHOh6Ot3VN3sI9WSAd8R7sBwn0o)
